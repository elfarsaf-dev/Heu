import { Loader2 } from "lucide-react";

interface LoadingModalProps {
  isVisible: boolean;
}

export function LoadingModal({ isVisible }: LoadingModalProps) {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm z-50 flex items-center justify-center" data-testid="loading-modal">
      <div className="bg-white rounded-3xl p-8 max-w-sm mx-4 shadow-2xl border border-gray-100">
        <div className="text-center">
          <div className="bg-gradient-to-br from-villa-blue to-indigo-600 rounded-full p-4 mx-auto mb-6 shadow-lg">
            <Loader2 className="animate-spin h-8 w-8 text-white" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">🤖 Memproses Template...</h3>
          <p className="text-gray-600 text-sm">AI sedang memformat fasilitas Anda dengan template yang menarik</p>
        </div>
      </div>
    </div>
  );
}
