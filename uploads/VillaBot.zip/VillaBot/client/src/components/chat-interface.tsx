import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { ChatMessage } from "@shared/schema";
import { MessageBubble } from "./message-bubble";
import { LoadingModal } from "./loading-modal";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { generateTemplate } from "@/services/api";
import { Send, Trash2, Home, Lightbulb } from "lucide-react";
import { nanoid } from "nanoid";

export function ChatInterface() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");

  const generateMutation = useMutation({
    mutationFn: generateTemplate,
    onSuccess: (response) => {
      const aiMessage: ChatMessage = {
        id: nanoid(),
        content: response,
        type: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMessage]);
    },
    onError: (error) => {
      const errorMessage: ChatMessage = {
        id: nanoid(),
        content: 'Maaf, terjadi kesalahan saat memproses template Anda. Silakan coba lagi.',
        type: 'error',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
      console.error('API Error:', error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const message = inputValue.trim();
    if (!message) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: nanoid(),
      content: message,
      type: 'user',
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMessage]);
    
    // Clear input and call API
    setInputValue("");
    generateMutation.mutate(message);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const clearChat = () => {
    if (window.confirm('Hapus semua percakapan?')) {
      setMessages([]);
    }
  };

  const charCount = inputValue.length;
  const maxChars = 1000;
  const isOverLimit = charCount > maxChars;

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-villa-blue to-indigo-600 sticky top-0 z-50 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-white/20 p-3 rounded-full backdrop-blur-sm">
                <Home className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">ELFAR.DEV BOT</h1>
                <p className="text-blue-100 text-sm">🤖 AI Fasilitas Generator</p>
              </div>
            </div>
            <Button
              onClick={clearChat}
              variant="secondary"
              size="sm"
              className="bg-white/20 hover:bg-white/30 border-white/30 text-white backdrop-blur-sm"
              data-testid="button-clear-chat"
            >
              <Trash2 size={16} className="mr-1" />
              Clear
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 pb-32">
        {/* Welcome Message */}
        <div className="py-6">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-gradient-to-br from-villa-blue to-indigo-500 p-3 rounded-full">
                <Home size={24} className="text-white" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-gray-900">Selamat Datang! 👋</h2>
                <p className="text-gray-600">AI Assistant untuk template villa & glamping</p>
              </div>
            </div>
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-4 border border-blue-100">
              <h3 className="font-semibold mb-3 text-gray-800">🚀 Cara Penggunaan:</h3>
              <div className="space-y-2 text-sm text-gray-700">
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 bg-villa-blue rounded-full"></span>
                  <span>Masukkan deskripsi fasilitas villa/glamping Anda</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 bg-villa-green rounded-full"></span>
                  <span>AI akan memformat sesuai template standar</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
                  <span>Salin hasil yang sudah diformat untuk digunakan</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Chat Messages */}
        <div className="space-y-4" data-testid="chat-messages">
          {messages.map((message) => (
            <MessageBubble key={message.id} message={message} />
          ))}
        </div>

        {/* Example Input */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 mb-6 mt-8">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-gradient-to-br from-green-400 to-green-500 p-2 rounded-full">
              <Lightbulb className="text-white" size={18} />
            </div>
            <h3 className="font-bold text-gray-900">💬 Contoh Input</h3>
          </div>
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl p-5 border border-green-200">
            <div className="whitespace-pre-line text-gray-800 text-sm leading-relaxed">
{`villa sunrise garden lokasi bogor
harga weekend 800rb weekday 500rb
ada kolam renang private
kamar 3 queen bed
kamar mandi dalam ada water heater
wifi smart tv
dapur lengkap kulkas
parkir luas
kapasitas 8 orang
cocok keluarga besar`}
            </div>
          </div>
        </div>

        {/* Example Output */}
        <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-gradient-to-br from-villa-blue to-indigo-500 p-2 rounded-full">
              <Lightbulb className="text-white" size={18} />
            </div>
            <h3 className="font-bold text-gray-900">✨ Contoh Output</h3>
          </div>
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-5 border border-blue-200">
            <div className="whitespace-pre-line text-gray-800 text-sm leading-relaxed">
{`🏠 *Villa Sunrise Garden*
📍 Bogor

💰 _*Harga*_
🎉 Weekend Rp 800.000
💵 Weekday Rp 500.000

👨‍👩‍👧‍👦 Cocok untuk keluarga besar dan acara keluarga 👪

👥 Kapasitas hingga 8 orang

🎯 Fasilitas :
✅ Private Pool
✅ 3 Bed Queen Size
✅ Kamar Mandi Dalam
✅ Water Heater
✅ Wi-Fi Available
✅ Smart TV
✅ Dapur Lengkap
✅ Kulkas
✅ Area Parkir Luas

📛 Note:
⏩ Check in jam 14.00
⏪ Check out jam 12.00
🚻 Bukti nikah untuk pasangan
🍺 No miras
🔞 No mesum
🏴‍☠️ No drugs

Terima kasih atas perhatian nya... 🙏🙏🙏`}
            </div>
          </div>
        </div>
      </main>

      {/* Input Section */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 shadow-2xl backdrop-blur-lg">
        <div className="max-w-4xl mx-auto p-4">
          <form onSubmit={handleSubmit} className="flex items-end space-x-3">
            <div className="flex-1 relative">
              <Textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ketik deskripsi fasilitas villa atau glamping..."
                className="resize-none rounded-3xl border-gray-200 focus:border-villa-blue focus:ring-villa-blue pr-16 py-4 shadow-sm"
                rows={3}
                data-testid="input-message"
              />
              <div className={`absolute bottom-3 right-4 text-xs font-medium ${isOverLimit ? 'text-red-500' : 'text-gray-400'}`}>
                {charCount}/{maxChars}
              </div>
            </div>
            <Button
              type="submit"
              disabled={!inputValue.trim() || isOverLimit || generateMutation.isPending}
              className="bg-gradient-to-r from-villa-blue to-indigo-600 hover:from-villa-blue hover:to-indigo-700 text-white rounded-full w-14 h-14 p-0 shadow-lg"
              data-testid="button-send"
            >
              <Send size={20} />
            </Button>
          </form>
        </div>
      </div>

      {/* Loading Modal */}
      <LoadingModal isVisible={generateMutation.isPending} />
    </div>
  );
}
