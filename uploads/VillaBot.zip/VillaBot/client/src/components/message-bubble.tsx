import { ChatMessage } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Copy, Check, User, Bot, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface MessageBubbleProps {
  message: ChatMessage;
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      toast({
        title: "Berhasil disalin!",
        description: "Template telah disalin ke clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
      toast({
        title: "Gagal menyalin",
        description: "Silakan salin manual",
        variant: "destructive",
      });
    }
  };

  if (message.type === 'user') {
    return (
      <div className="flex justify-end animate-fadeIn mb-4" data-testid={`message-user-${message.id}`}>
        <div className="bg-gradient-to-r from-villa-blue to-indigo-600 text-white rounded-3xl rounded-br-lg px-6 py-4 max-w-2xl shadow-lg">
          <div className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</div>
          <div className="text-xs text-blue-100 mt-2 text-right">
            {new Date(message.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    );
  }

  if (message.type === 'ai') {
    return (
      <div className="flex justify-start animate-fadeIn mb-4" data-testid={`message-ai-${message.id}`}>
        <div className="flex items-start space-x-3 max-w-4xl">
          <div className="bg-gradient-to-br from-villa-blue to-indigo-600 p-2 rounded-full flex-shrink-0 shadow-lg">
            <Bot size={16} className="text-white" />
          </div>
          <div className="flex-1">
            <div className="bg-white rounded-3xl rounded-bl-lg px-6 py-4 shadow-lg border border-gray-100">
              <div className="bg-gray-50 rounded-2xl p-4 font-mono text-sm whitespace-pre-line mb-4 border border-gray-100">
                {message.content}
              </div>
              <div className="flex items-center justify-between">
                <div className="text-xs text-gray-500">
                  {new Date(message.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                </div>
                <Button
                  onClick={copyToClipboard}
                  disabled={copied}
                  className="bg-gradient-to-r from-villa-green to-emerald-600 hover:from-villa-green hover:to-emerald-700 text-white rounded-full shadow-lg"
                  size="sm"
                  data-testid={`button-copy-${message.id}`}
                >
                  {copied ? (
                    <>
                      <Check size={14} className="mr-1" />
                      Tersalin!
                    </>
                  ) : (
                    <>
                      <Copy size={14} className="mr-1" />
                      Salin Template
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (message.type === 'error') {
    return (
      <div className="flex justify-start animate-fadeIn mb-4" data-testid={`message-error-${message.id}`}>
        <div className="flex items-start space-x-3 max-w-3xl">
          <div className="bg-gradient-to-br from-red-500 to-red-600 p-2 rounded-full flex-shrink-0 shadow-lg">
            <AlertTriangle size={16} className="text-white" />
          </div>
          <div className="bg-red-50 rounded-3xl rounded-bl-lg px-6 py-4 shadow-lg border border-red-200">
            <div className="text-red-700 text-sm leading-relaxed">{message.content}</div>
            <div className="text-xs text-red-500 mt-2">
              {new Date(message.timestamp).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
