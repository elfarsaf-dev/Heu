# Overview

This is a React-based web application that serves as an AI-powered template generator for villa and glamping facility descriptions. The application provides a chat interface where users can input raw facility information, and the system formats it into professional, attractive templates using an external AI service. The app focuses on Indonesian villa/glamping businesses and generates standardized templates with pricing, facilities, and booking information.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

**React with TypeScript**: The client is built using React 18 with TypeScript for type safety. The application uses a modern functional component approach with hooks for state management.

**UI Framework**: Implements shadcn/ui components built on top of Radix UI primitives, providing a consistent and accessible design system. The styling uses Tailwind CSS with a custom theme configuration supporting both light and dark modes.

**Routing**: Uses Wouter for lightweight client-side routing, with a simple two-page structure (Home and NotFound).

**State Management**: Leverages React Query (@tanstack/react-query) for server state management, API caching, and data synchronization. Local component state is managed with React hooks.

## Backend Architecture

**Express.js Server**: The backend uses Express.js with TypeScript, configured for both development and production environments. The server handles API routing with middleware for JSON parsing and request logging.

**Development Setup**: Integrates Vite for hot module replacement and development tooling, with custom middleware for serving the React application in development mode.

**Storage Interface**: Implements an abstraction layer for data storage with an in-memory implementation (MemStorage) that can be easily swapped for database-backed storage. The interface supports basic CRUD operations for user management.

## Database Design

**Drizzle ORM**: Configured to use PostgreSQL with Drizzle ORM for type-safe database operations. The setup includes migration support and environment-based configuration.

**Schema Structure**: Defines schemas for chat messages and API responses using Zod for runtime validation and type inference. The shared schema ensures type consistency between frontend and backend.

## External Dependencies

**AI Service Integration**: Integrates with a third-party AI API (api.ferdev.my.id) for generating villa/glamping templates. The service uses a custom logic prompt to format user input into standardized Indonesian business templates.

**Neon Database**: Configured to work with Neon's serverless PostgreSQL offering through the @neondatabase/serverless package, providing scalable database hosting.

**UI Components**: Extensive use of Radix UI primitives for accessible, unstyled components that are then styled with Tailwind CSS through the shadcn/ui system.

**Development Tools**: 
- Vite for build tooling and development server
- ESBuild for production bundling
- TypeScript for type checking
- Tailwind CSS for styling
- PostCSS for CSS processing

**Session Management**: Includes connect-pg-simple for PostgreSQL-backed session storage, enabling user session persistence across requests.

## API Architecture

**RESTful Design**: The backend follows REST principles with API routes prefixed under `/api`. The current implementation provides a foundation for CRUD operations through the storage interface.

**Error Handling**: Implements centralized error handling middleware that provides consistent error responses with appropriate HTTP status codes.

**Request Logging**: Custom middleware logs API requests with timing information and response data for debugging and monitoring purposes.

## Build and Deployment

**Development Mode**: Uses tsx for TypeScript execution in development with hot reloading capabilities.

**Production Build**: Separates client and server builds - Vite handles the client bundle while ESBuild processes the server code for Node.js deployment.

**Environment Configuration**: Supports environment-based configuration for database connections and API keys, with proper error handling for missing required variables.