import { z } from "zod";

export const chatMessageSchema = z.object({
  id: z.string(),
  content: z.string(),
  type: z.enum(['user', 'ai', 'error']),
  timestamp: z.date(),
});

export const apiResponseSchema = z.object({
  success: z.boolean(),
  status: z.number(),
  author: z.string().optional(),
  message: z.string(),
});

export type ChatMessage = z.infer<typeof chatMessageSchema>;
export type ApiResponse = z.infer<typeof apiResponseSchema>;
